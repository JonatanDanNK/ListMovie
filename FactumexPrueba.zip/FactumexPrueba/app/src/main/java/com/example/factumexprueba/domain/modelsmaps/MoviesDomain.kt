package com.example.factumexprueba.domain.modelsmaps

import com.example.factumexprueba.data.database.entities.MovieEntity
import com.google.gson.annotations.SerializedName
import com.monique.projetointegrador.domain.model.Movie

data class MoviesDomain(

    val id: Int,
    val imgHome: String? = null,
    val title: String? = null,
    val rating: Float,
   // val genreIds: List<Int>,
    var isFavorite: Boolean = false,
)
fun Movie.toDomain() = MoviesDomain(id = id, imgHome = imgHome, title = title, rating = rating, isFavorite = isFavorite)
fun MovieEntity.toDomain() = MoviesDomain(id = id, imgHome = imgHome, title = title, rating = rating, isFavorite = isFavorite)

