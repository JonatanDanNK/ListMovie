package com.monique.projetointegrador.data.remotesource

import com.example.factumexprueba.domain.model.MovieList
import com.monique.projetointegrador.data.model.movies.MoviesListResponse
import com.monique.projetointegrador.domain.model.Movie
import retrofit2.Response
import retrofit2.http.GET


interface MoviesRemoteSource {

    @GET("movie/popularL")
    suspend fun getPopularMovies(): Response<MovieList>

}