package com.example.factumexprueba.data.model.movies

import com.google.gson.annotations.SerializedName
import com.monique.projetointegrador.domain.model.Movie

data class MovieListResponse(
    @SerializedName("results")
    val movieResults: List<Movie>
)
