package com.example.factumexprueba.domain.modelfirebase

data class Ubication(
    val latitude: Double,
    val longitude: Double,
    val time: Any
)
