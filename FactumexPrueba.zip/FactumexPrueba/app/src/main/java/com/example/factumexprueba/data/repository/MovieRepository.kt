package com.example.factumexprueba.data.repository

import com.example.factumexprueba.data.database.dao.MoviesDao
import com.example.factumexprueba.data.database.entities.MovieEntity
import com.example.factumexprueba.data.services.MoviesServiceImpl
import com.example.factumexprueba.domain.model.MovieList
import com.example.factumexprueba.domain.modelsmaps.Movies
import com.example.factumexprueba.domain.modelsmaps.MoviesDomain
import com.example.factumexprueba.domain.modelsmaps.toDomain
import com.monique.projetointegrador.domain.model.Movie
import javax.inject.Inject

class MovieRepository @Inject constructor(
    private val movieService: MoviesServiceImpl,
    private val moviesDao: MoviesDao
){

    suspend fun getMoviresServicesFromApi(): MovieList{
        return movieService.getPopularMovies()
    }

    suspend fun getMoviresServicesDromBd(): List<MoviesDomain> {
        val response: List<MovieEntity> = moviesDao.getAllMovies()
        return response.map { it.toDomain() }
    }

    suspend fun insertMovies(movies:List<MovieEntity>){
        moviesDao.insertAllMovies(movies)

    }

    suspend fun clearMovies() {
        moviesDao.deleteAllMovies()
    }
}