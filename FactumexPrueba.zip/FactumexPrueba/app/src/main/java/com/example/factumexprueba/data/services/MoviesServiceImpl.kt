package com.example.factumexprueba.data.services

import com.example.factumexprueba.domain.model.MovieList
import com.monique.projetointegrador.data.base.Network
import com.monique.projetointegrador.data.model.movies.MoviesListResponse
import com.monique.projetointegrador.data.remotesource.MoviesRemoteSource
import com.monique.projetointegrador.domain.model.Movie
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class MoviesServiceImpl @Inject constructor(
    private val moviesRemoteSource:MoviesRemoteSource
)  {
    suspend fun getPopularMovies(): MovieList {
       return withContext(Dispatchers.IO){
           val result = moviesRemoteSource.getPopularMovies()
           result.body() ?: MovieList(emptyList())
       }
    }
}