package com.example.factumexprueba.domain.modelsmaps

import com.example.factumexprueba.domain.model.MovieList
import com.monique.projetointegrador.data.model.movies.MoviesListResponse
import com.monique.projetointegrador.domain.model.Movie

data class Movies(
    val movieResults: List<MoviesDomain>
)

