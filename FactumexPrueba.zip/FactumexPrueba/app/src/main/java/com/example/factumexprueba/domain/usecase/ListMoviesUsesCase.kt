package com.example.factumexprueba.domain.usecase

import com.example.factumexprueba.data.database.entities.MovieEntity
import com.example.factumexprueba.data.database.entities.toDatabase
import com.example.factumexprueba.data.repository.MovieRepository
import com.example.factumexprueba.data.services.MoviesServiceImpl
import com.example.factumexprueba.domain.model.MovieList
import com.example.factumexprueba.domain.modelsmaps.Movies
import com.example.factumexprueba.domain.modelsmaps.MoviesDomain
import com.monique.projetointegrador.data.model.movies.MovieResponse
import com.monique.projetointegrador.data.model.movies.MoviesListResponse
import com.monique.projetointegrador.domain.model.Movie
import javax.inject.Inject


class ListMoviesUsesCase @Inject constructor(
    private val moviesRepository: MovieRepository
) {
    suspend operator fun invoke(): MovieList {

        val response = moviesRepository.getMoviresServicesFromApi()
        val map: List<Movie> = response.movieResults
        return if(map.isNotEmpty()){
            moviesRepository.clearMovies()
            moviesRepository.insertMovies(map.map { it.toDatabase() })
            response
        }else{
            moviesRepository.getMoviresServicesDromBd() as MovieList

        }
    }
}