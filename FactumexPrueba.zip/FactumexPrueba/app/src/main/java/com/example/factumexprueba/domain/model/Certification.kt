package com.monique.projetointegrador.domain.model

class Certification(
    val certification: String,
    val type: Int
    )