package com.example.factumexprueba

import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.factumexprueba.databinding.ActivityMapsBinding
import com.example.factumexprueba.domain.modelfirebase.Ubication
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.firebase.FirebaseApp
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import java.time.Instant

class MapsActivity : AppCompatActivity() {

    private lateinit var _mBinding: ActivityMapsBinding
    private lateinit var ubication: FusedLocationProviderClient
    private lateinit var databse: FirebaseDatabase
    private lateinit var refubication: DatabaseReference



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        _mBinding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(_mBinding.root)

       // databse = FirebaseDatabase.getInstance()
        //refubication = databse.getReference("Ubication")

        val myHandler = Handler(Looper.getMainLooper())

        myHandler.post(object : Runnable {
            override fun run() {
                getPermissionUbication()
                myHandler.postDelayed(this, 300000)
            }
        })


    }

    private fun getPermissionUbication() {
        if (ContextCompat.checkSelfPermission(
                this@MapsActivity,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            //Toast.makeText(this, "Se tiene permiso", Toast.LENGTH_SHORT).show()
        } else {
            ActivityCompat.requestPermissions(
                this@MapsActivity,
                arrayOf(
                    android.Manifest.permission.ACCESS_COARSE_LOCATION,
                    android.Manifest.permission.ACCESS_FINE_LOCATION
                ),
                1
            )
        }
        ubication = LocationServices.getFusedLocationProviderClient(this)
   /*     ubication.lastLocation.addOnSuccessListener { location : Location? ->
               if (location != null) {
                   val latitude = location.latitude
                   val longitude: Double = location.longitude
                   val time = Instant.now()
                   Toast.makeText(this, "Latitud: "+latitude+" longitud: "+longitude, Toast.LENGTH_SHORT).show()
                   System.out.println("Latitud: "+latitude+" longitud: "+longitude+" time:"+time)

                   val ubit: Ubication = Ubication(latitude, longitude, time )

                }
        }*/
    }

}