package com.example.factumexprueba.iu

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.factumexprueba.domain.modelsmaps.MoviesDomain
import com.example.factumexprueba.domain.usecase.ListMoviesUsesCase
import com.monique.projetointegrador.domain.model.Movie
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeMoviesViewModel @Inject constructor(
    private val moviesUsesCase: ListMoviesUsesCase
): ViewModel() {

    private val _listMovies = MutableLiveData<List<Movie>>()
    val listMovies : LiveData<List<Movie>> = _listMovies

    fun getAllMovies(){
        viewModelScope.launch {
            val result = moviesUsesCase()
            System.out.println(result)
            if(result.movieResults != emptyList<Movie>()) {
                _listMovies.value = result.movieResults
                System.out.println("Hola")
            }else{
                _listMovies.value = mutableListOf()
            }
        }
    }


}