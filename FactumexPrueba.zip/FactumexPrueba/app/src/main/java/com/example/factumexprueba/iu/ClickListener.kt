package com.example.factumexprueba.iu

import com.monique.projetointegrador.domain.model.Movie

interface ClickListener {
    fun openMovieDetails(movieId: Int)
    fun loadMoviesWithGenre(genreIds: List<Int>)
    fun onFavoriteClickedListener(movie: Movie, isChecked: Boolean)
}