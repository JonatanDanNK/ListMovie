package com.example.factumexprueba.data.repository

import com.monique.projetointegrador.domain.model.Movie

class MoviesList {

}