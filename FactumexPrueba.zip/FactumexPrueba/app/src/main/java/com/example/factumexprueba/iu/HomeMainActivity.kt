package com.example.factumexprueba.iu

import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.example.factumexprueba.R
import com.example.factumexprueba.databinding.FragmentHomeMoviesBinding
import com.example.factumexprueba.databinding.HomeMainBinding
import com.monique.projetointegrador.presentation.adapter.MoviesRvAdapter
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class HomeMainActivity : AppCompatActivity() {


    private lateinit var _mBinding: HomeMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _mBinding = HomeMainBinding.inflate(layoutInflater)
        setContentView(_mBinding.root)



    }


}

